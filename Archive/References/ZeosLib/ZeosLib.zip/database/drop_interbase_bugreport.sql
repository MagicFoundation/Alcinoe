/*==============================================================*/
/* Database name:  zeoslib.gdb                                  */
/* DBMS name:      Interbase 6                                  */
/*==============================================================*/

DROP TRIGGER TRIGGER841559;
DROP TABLE TABLE789879;
DROP TABLE TABLE841559;
DROP TABLE TABLE865441;
DROP EXCEPTION EXCEPTION841559;
DROP TABLE TABLE864622;
DROP TABLE TABLE886914;
DROP TABLE TABLE886194;
DROP TABLE TABLE897631;
DROP TABLE TABLE909181;
DROP TABLE TABLE920450;
DROP TABLE TABLE1021705;
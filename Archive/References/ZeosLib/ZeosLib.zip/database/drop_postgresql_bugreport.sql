/*==============================================================*/
/* Database name:  PostgreSql                                   */
/* DBMS name:      PostgreSQL 7                                 */
/* Created on:     04.02.2003 19:59:06                          */
/*==============================================================*/

drop table test739514;
drop table test739519;
drop table test766053a;
drop table test766053b;
drop table test816846;

drop table "insert";

drop table test894367b;
drop table test894367a;

/*==============================================================*/
/* Database name:  PostgreSql                                   */
/* DBMS name:      PostgreSQL 7                                 */
/* Created on:     04.02.2003 19:59:06                          */
/*==============================================================*/


drop table test815852;
drop table xyz.test824780;
drop table test824780;
drop schema xyz;

drop domain tinteger;
drop domain tstring;
drop table test1014416;
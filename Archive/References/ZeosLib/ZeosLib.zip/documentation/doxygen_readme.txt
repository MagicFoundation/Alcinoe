This document contains the necessary information to build the doxygen documentation for zeoslib.
This documentation subproject has been started by bravecobra because the existing documentation wass quite outdated.

To extract the documentation from the zeoslib sources you need to download and install 2 projects:
1. Doxygen : http://www.stack.nl/~dimitri/doxygen/ or http://www.doxygen.org/
-> just download and use the installer.
2. Pas2dox : http://pas2dox.sourceforge.net/
-> just download the executable and put it somewhere in your system path. (After installing doxygen the doxygen binaries folder is a good choice)

Once these projects are installed and the doxxygen and pas2dox binaries are in your system path you should just start doxygen_build.bat (windows) or doxygen_build.sh (unix/linux) from the zeoslib 'documentation' directory to start the generation of the documentation in a new folder ../doc

More information on the use of doxygen for the zeoslib project can be found here: (by Bravecobra)
- what's doxygen an how to document the zeoslib sources : http://test.bravecobra.com/zeoslib/
- the daily zeoslib doxygen documentation builds : http://test.bravecobra.com/zeoslib/full/html/ or (components only) http://test.bravecobra.com/zeoslib/components/html/

If you have idea's or want to contribute documentation feel free to experiment and share your findings in the 'Documentation' forum at http://zeos.firmos.at/

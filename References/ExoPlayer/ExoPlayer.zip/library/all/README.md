# ExoPlayer full library #

An empty module that depends on all of the other library modules. Depending on
the full library is equivalent to depending on all of the other library modules
individually. See ExoPlayer's [top level README][] for more information.

[top level README]: https://github.com/google/ExoPlayer/blob/release-v2/README.md

## Links ##

* [Javadoc][]: Note that this Javadoc is combined with that of other modules.

[Javadoc]: https://google.github.io/ExoPlayer/doc/reference/index.html

Name: Andreas Hausladen
E-mail: Andreas DoTt Hausladen aTt gmx DoTt de
Sourceforge unix name: ahuser

Some years ago I had written a unit that makes Shared Memory usage as easy
as calling GetMem/FreeMem. I would like to donate them to the JCL.
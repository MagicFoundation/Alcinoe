TSynJSONTreeView
================

By *EMartin* (Esteban Martin).


# Presentation

`TSynJSONTreeView` is a treeview supporting mORMot's JSON document, the allowed tasks are:

- edit a node
- delete a node
- add a node
- save to file
- load from file
- generate JSON to string variable
- implement a custom input for edit/insert node

# Forum Thread

See http://synopse.info/forum/viewtopic.php?id=3451

# TODO

- FPC support (I just use Windows)
- Developed with Delphi 7, not tested with any other Delphi version.

# License

Feel free to use and/or append to Lib and extend if needed.

Third Party Demos
=================

You would find in those sub-folders some code received from
various *mORMot* users.

Feel free to send us your own projects.
If they are stable enough, and do not take too much place,
we would likely publish them here!

All code here is licensed to be of public domain.
Copyright remains to the initial developper.


Disclamer:
----------

Note that this code is just shared here for educational purposes,
and is not part of the *mORMot* framework.

You can take a look at it, but we would not support any of those
projects. Those are unofficial demos, to use at your own risk.

You have been warned!

Final note
----------

We thank a lot the authors for sharing their work!
And we are waiting for yours!

The *mORMot team*
Facebook Audience Network for Android

Documentation
https://developers.facebook.com/docs/audience-network


Name: Virgo P�rna
mail: virgo doTt parna AtT mail dOtT ee

	I decided to upgrade currently used JCL 1.91 to 1.96. When testing new
version I discovered, that it no longer supports Windows 95.   While
Windows 95 is no longer supported by Microsoft we still have clients
using it, so I decided to check out, why it no longer works under
Windows 95 (when used as package).
	From what I understand Windows 95 support was lost, when contributions
by P*H* were removed. So I wrote last evening some my own wrappers
around those functions that are not supported by Windows 95 (several
were used in JclSynch, on in JclFileutils (from kernel32.dll) and then
there were opengl32.dll functions and one glu32.dll function in
JclSysInfo. I posted my wrappers (completely untested except opengl
wrappers) to binaries group (subject "Windows 95 support functions" -
JclWin32Ex.pas).
	There is slight difference with OpenGl wrappers - InitializeOpenGl must
be called before using them (I didn't want to initialize opengl dll
handles on unit initialization, because I remeber having a problem -
when Windows NT service depended on opengl32.dll - always initializing
the dll would probably be just as bad).